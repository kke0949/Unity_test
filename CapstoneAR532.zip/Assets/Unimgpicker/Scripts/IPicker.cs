﻿namespace Kakera
{
    internal interface IPicker
    {
        void Show(string title, string outputFileName, int maxSize);
    }
}